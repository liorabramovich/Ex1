import json
import csv
from objects import CBuilding
from objects import CElevatorAlgo
from objects import CElevatorCall
import sys


def outputCalls(newCalls):
    callsFile = open("outputCalls.csv", "w", newline='')
    callsWriter = csv.writer(callsFile)
    for line in newCalls:
        callsWriter.writerow(line)


def loadBuilding(building):
    cbuilding = CBuilding.CBuilding(building["_minFloor"], building["_maxFloor"], building["_elevators"])
    return cbuilding


def loadCalls(callsReader):
    callsList = []
    for line in callsReader:
        callsList.append(CElevatorCall.CElevatorCall(line[2], line[3], line[1], line[5]))
    return callsList


def main():
    cBuilding = 0
    callsList = []
    if len(sys.argv) < 3:
        while True:
            try:
                buildingFile = open(input('please enter the path for the Building json file: '))
                building = json.load(buildingFile)
                cBuilding = loadBuilding(building)
                break
            except:
                print("Error! Please Try again.")

        while True:
            try:
                callsFile = open(input("please enter the path for the calls csv file: "))
                callsReader = csv.reader(callsFile)
                callsList = loadCalls(callsReader)
                break
            except:
                print("Error! Please try again.")
    else:
        try:
            buildingFile = open(sys.argv[1])
            building = json.load(buildingFile)
            cBuilding = loadBuilding(building)
        except:
            print("Error! Please Try again.")

        try:
            callsFile = open(sys.argv[0])
            callsReader = csv.reader(callsFile)
            callsList = loadCalls(callsReader)
        except:
            print("Error! Please try again.")

    print("Started...\n")
    elevAlgo = CElevatorAlgo.CElevatorAlgo(cBuilding)
    newCallList = []
    for call in callsList:
        newCall = ['Elevator call', str(call.getCallTime()), str(call.getSrc()), str(call.getDest()), '0']
        elevId = elevAlgo.allocateAnElevator(call)
        newCall.append(str(elevId))
        newCallList.append(newCall)
    outputCalls(newCallList)
    print("Completed: Output file path = outputCalls.csv")



if __name__ == '__main__':
    main()

